
				<!-- Start Comment -->
				<div class="comments">
					<h3 class="fword">7 Comments</h3>
					<ol>
						<li>
							<div class="commbox">
								<div class="grid_2 alpha">
                                                                    	<img src="images/image.jpg" width="93" height="93" alt="image" class="circle"/><!--"http://placehold.it/93x93"-->
								</div>
								<div class="grid_10 omega">
									<p class="authname">Todd Eddy</p>
									<p class="comdate">Wednesday, February 29th, 2013</p>
									<p>Are there any other “image lipsum” sites out there? I recall one where it was basically a small graphic that was royalty free and allowed you to choose from a few different color schemes. I liked it over the “400 x 800″ text you see on other placeholder images.</p>
								</div>
								<div class="clearfix"></div>
							</div>
							<ol>
								<li>
									<div class="commbox">
										<div class="grid_2 alpha">
                                                                                    <img src="images/image.jpg" width="93" height="93" alt="image" class="circle"/><!--"http://placehold.it/93x93"-->
										</div>
										<div class="grid_10 omega">
											<p class="authname">Todd Eddy</p>
											<p class="comdate">Wednesday, February 29th, 2013</p>
											<p>Are there any other “image lipsum” sites out there? I recall one where it was basically a small graphic that was royalty free and allowed you to choose from a few different color schemes. I liked it over the “400 x 800″ text you see on other placeholder images.</p>
										</div>
										<div class="clearfix"></div>
									</div>
								</li>
								<li>
									<div class="commbox">
										<div class="grid_2 alpha">
                                                                                    <img src="images/image.jpg" width="93" height="93" alt="image" class="circle"/><!--"http://placehold.it/93x93"-->
										</div>
										<div class="grid_10 omega">
											<p class="authname">Todd Eddy</p>
											<p class="comdate">Wednesday, February 29th, 2013</p>
											<p>Are there any other “image lipsum” sites out there? I recall one where it was basically a small graphic that was royalty free and allowed you to choose from a few different color schemes. I liked it over the “400 x 800″ text you see on other placeholder images.</p>
										</div>
										<div class="clearfix"></div>
									</div>
									<ol>
										<li>
											<div class="commbox">
												<div class="grid_2 alpha">
                                                                                                    <img src="images/image.jpg" width="93" height="93" alt="image" class="circle"/><!--"http://placehold.it/93x93"-->
												</div>
												<div class="grid_10 omega">
													<p class="authname">Todd Eddy</p>
													<p class="comdate">Wednesday, February 29th, 2013</p>
													<p>Are there any other “image lipsum” sites out there? I recall one where it was basically a small graphic that was royalty free and allowed you to choose from a few different color schemes. I liked it over the “400 x 800″ text you see on other placeholder images.</p>
												</div>
												<div class="clearfix"></div>
											</div>
										</li>
										<li>
											<div class="commbox">
												<div class="grid_2 alpha">
                                                                                                    <img src="images/image.jpg" width="93" height="93" alt="image" class="circle"/><!--"http://placehold.it/93x93"-->
												</div>
												<div class="grid_10 omega">
													<p class="authname">Todd Eddy</p>
													<p class="comdate">Wednesday, February 29th, 2013</p>
													<p>Are there any other “image lipsum” sites out there? I recall one where it was basically a small graphic that was royalty free and allowed you to choose from a few different color schemes. I liked it over the “400 x 800″ text you see on other placeholder images.</p>
												</div>
												<div class="clearfix"></div>
											</div>
										</li>
									</ol>
								</li>
							</ol>
						</li>
						<li>
							<div class="commbox">
								<div class="grid_2 alpha">
                                                                    <img src="images/image.jpg" width="93" height="93" alt="image" class="circle"/><!--"http://placehold.it/93x93"-->
								</div>
								<div class="grid_10 omega">
									<p class="authname">Todd Eddy</p>
									<p class="comdate">Wednesday, February 29th, 2013</p>
									<p>Are there any other “image lipsum” sites out there? I recall one where it was basically a small graphic that was royalty free and allowed you to choose from a few different color schemes. I liked it over the “400 x 800″ text you see on other placeholder images.</p>
								</div>
								<div class="clearfix"></div>
							</div>
						</li>
						<li>
							<div class="commbox">
								<div class="grid_2 alpha">
                                                                    <img src="images/image.jpg" width="93" height="93" alt="image" class="circle"/><!--"http://placehold.it/93x93"-->
								</div>
								<div class="grid_10 omega">
									<p class="authname">Todd Eddy</p>
									<p class="comdate">Wednesday, February 29th, 2013</p>
									<p>Are there any other “image lipsum” sites out there? I recall one where it was basically a small graphic that was royalty free and allowed you to choose from a few different color schemes. I liked it over the “400 x 800″ text you see on other placeholder images.</p>
								</div>
								<div class="clearfix"></div>
							</div>
						</li>
					</ol>
					<div class="clearfix"></div><br/>
					
					<!-- FORM -->
					<form name="some_name" action="{form action link}" method="post">
						<label for="name">Name*</label>
						<input type="text" name="name" />
						
						<label for="email">Email*</label>
						<input type="email" name="email" />
						
						<label for="url">Url*</label>
						<input type="text" name="url" />
						
						<label for="comment">Comment*</label>
						<textarea rows="10" name="comment"></textarea>
						
						<input type="submit" value="Post Comment" class="btn mainclr"/>
					</form>
				</div>
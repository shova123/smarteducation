
<?php  
//    $this->load->helper('file');
//    $read_path= $_GET['val'];
//    $readFF = read_file($read_path,true);
//    echo $readFF;
    echo $full_path;
?>